# BNB Smart Chain 隐私协议与隐匿转账 — 使用文档

本仓库包含两个独立合约，部署在 **BNB Smart Chain（币安智能链）**：

| 文件 | 合约 | 作用 |
|------|------|------|
| `Privacy_Policy.sol` | `PrivacyPolicy` | 链上隐私协议登记、版本与用户确认 |
| `PrivacyTransfer.sol` | `PrivacyTransfer` | 通过合约转账，存款和合约内划转不出现收款地址 |

两个合约无依赖、互不调用，可分别部署。

- 主网 Chain ID：`56`（[BscScan](https://bscscan.com)）
- 测试网 Chain ID：`97`（[BscScan Testnet](https://testnet.bscscan.com)）
- 编译器：Solidity `0.8.20` 或更高
- Optimizer：建议开启，runs = `200`

---

## 1. 隐匿转账能做什么、不能做什么

`PrivacyTransfer` 把资金锁进合约，用「承诺哈希」记账，而不是用钱包地址记账。

| 操作 | 收款钱包是否出现在这笔交易里 |
|------|------------------------------|
| `deposit` / `depositToken` 存款 | 否，只有 `commitment` |
| `stealthTransfer` 合约内划转 | 否，只有承诺哈希 |
| `withdraw` / `withdrawWithSig` 提现 | 是（资金打进钱包时无法避免） |

**仍然公开可见：**

- 存款交易的 `tx.from`（付 gas 的账户）
- 金额
- 提现交易的发起者和内部转账的收款地址

这不是混币器，也不能抹去付款人。丢失 `secret` 则资金无法取出，合约没有管理员、不能代为找回。

---

## 2. 用 Remix 部署

### 2.1 准备钱包

1. 安装 [MetaMask](https://metamask.io/)
2. 添加 BSC 网络：

| 字段 | 主网 | 测试网 |
|------|------|--------|
| 网络名称 | BNB Smart Chain | BSC Testnet |
| RPC | `https://bsc-dataseed.binance.org` | `https://data-seed-prebsc-1-s1.binance.org:8545` |
| Chain ID | `56` | `97` |
| 符号 | BNB | tBNB |
| 浏览器 | `https://bscscan.com` | `https://testnet.bscscan.com` |

3. 测试网领水：https://testnet.bnbchain.org/faucet-smart

### 2.2 编译

1. 打开 [Remix](https://remix.ethereum.org)
2. 将 `Privacy_Policy.sol`、`PrivacyTransfer.sol` 上传到 Remix
3. Compiler 选 `0.8.20` 或以上
4. 勾选 **Enable optimization**，runs 填 `200`
5. Compile

### 2.3 部署 PrivacyTransfer（隐匿转账）

1. 左侧 **Deploy & Run**
2. Environment 选 **Injected Provider - MetaMask**
3. 合约选 `PrivacyTransfer`
4. 无构造参数，直接 Deploy
5. 在区块浏览器验证源码，方便他人审计

部署后把合约地址保存下来，下文记为 `PRIVACY_TRANSFER`。

### 2.4 部署 PrivacyPolicy（隐私协议，可选）

构造参数：

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `_projectName` | string | 项目名称 | `Example DApp` |
| `_operatorName` | string | 运营主体 | `XX 科技有限公司` |
| `_contactEmail` | string | 隐私事务邮箱 | `privacy@example.com` |
| `_website` | string | 官网（含 https） | `https://example.com` |
| `_contentHash` | bytes32 | 完整协议正文的 keccak256 | 见下方 |
| `_documentURI` | string | 完整协议托管地址 | `ipfs://bafy...` 或 HTTPS |

计算 `_contentHash`（ethers v6）：

```js
const hash = ethers.keccak256(ethers.toUtf8Bytes(完整协议文本));
```

部署前请把 `Privacy_Policy.sol` 顶部注释里的 `【项目名称】`、联系方式和生效日期改成实际信息。本模板不构成法律意见，上线前应由律师审阅。

---

## 3. 隐匿转账：推荐流程

核心公式：

```text
commitment = keccak256(abi.encodePacked(secret, 收款人地址))
```

- `secret`：收款人自己生成的 32 字节随机数，**不要发给付款人，不要发到链上**（提现时才会用）
- `commitment`：可以安全发给付款人，付款人拿它去存款

ethers v6 计算：

```js
import { ethers } from "ethers";

const secret = ethers.hexlify(ethers.randomBytes(32));
const commitment = ethers.solidityPackedKeccak256(
  ["bytes32", "address"],
  [secret, recipientAddress]
);
```

也可以在 Remix 里调用只读方法 `computeCommitment(secret, recipientAddress)` 得到同样结果。请先保存 `secret`，丢失无法提现。

### 3.1 场景 A：付款人转给指定收款人（收款地址不上链）

```
收款人 ──生成 secret + commitment──► 把 commitment 发给付款人
付款人 ──deposit(commitment)──────► 合约记账（链上看不到收款地址）
收款人 ──withdraw(secret)─────────► 资金进入收款钱包（此时地址可见）
```

**收款人**

```js
const secret = ethers.hexlify(ethers.randomBytes(32));
const commitment = ethers.solidityPackedKeccak256(
  ["bytes32", "address"],
  [secret, await signer.getAddress()]
);
// 把 commitment 通过加密聊天发给付款人
// 本地妥善保存 secret
```

**付款人存 BNB**

```js
const contract = new ethers.Contract(PRIVACY_TRANSFER, abi, signer);

await contract.deposit(commitment, {
  value: ethers.parseEther("0.1"),
});
```

**付款人存 BEP20**

```js
const token = new ethers.Contract(TOKEN, erc20Abi, signer);
const amount = ethers.parseUnits("100", 18);

await (await token.approve(PRIVACY_TRANSFER, amount)).wait();
await contract.depositToken(TOKEN, amount, commitment);
```

BscScan 上这笔存款只能看到：付款人 → 本合约，以及一个 32 字节承诺。看不到收款钱包。

**确认到账（任何人可查）**

```js
const [token, amount] = await contract.noteOf(commitment);
// token === ethers.ZeroAddress 表示 BNB
// amount > 0 表示承诺下有余额
```

**收款人提现**

必须用承诺所绑定的那个钱包调用。`recipient` 填 `ethers.ZeroAddress` 则打给自己：

```js
await contract.withdraw(secret, ethers.ZeroAddress);
// 或指定另一地址收款（发起交易的仍是绑定钱包）：
await contract.withdraw(secret, "0x收款或自己的地址");
```

### 3.2 场景 B：合约内再转给下一个人（仍然不出现地址）

对方先按 3.1 的方法生成 **自己的** `newSecret` 和 `newCommitment`，把 `newCommitment` 给你。

你用**当前票据的 secret**，并且必须用绑定的钱包调用：

```js
// 全额转出，找零承诺填 32 字节全 0
await contract.stealthTransfer(
  secret,
  newCommitment,
  amount,
  ethers.ZeroHash
);
```

部分转出时必须同时准备一张「找零承诺」（绑定你自己）：

```js
const changeSecret = ethers.hexlify(ethers.randomBytes(32));
const changeCommitment = ethers.solidityPackedKeccak256(
  ["bytes32", "address"],
  [changeSecret, await signer.getAddress()]
);

await contract.stealthTransfer(
  secret,              // 当前票据密钥
  newCommitment,       // 对方的承诺
  sendAmount,          // 转出金额
  changeCommitment     // 剩余金额进入这张新票据
);
```

划转后：

- 旧 `commitment` 作废（`spent` 为 true）
- 对方用 `newSecret` 提现或再次划转
- 你自己的剩余资金用 `changeSecret` 控制

### 3.3 场景 C：收款人没有 BNB 付 gas（代付提现）

收款人链下签名，代付人提交 `withdrawWithSig`。

签名消息（与合约一致）：

```text
inner  = keccak256(abi.encode(
           secret, recipient, relayerFee, relayer, deadline,
           本合约地址, chainId
         ))
digest = keccak256("\x19Ethereum Signed Message:\n32" || inner)
```

ethers v6 示例：

```js
const recipient = await ownerSigner.getAddress();
const relayerFee = 0n;
const relayer = ethers.ZeroAddress;
const deadline = BigInt(Math.floor(Date.now() / 1000) + 3600);

const inner = ethers.keccak256(
  ethers.AbiCoder.defaultAbiCoder().encode(
    [
      "bytes32",
      "address",
      "uint256",
      "address",
      "uint256",
      "address",
      "uint256",
    ],
    [
      secret,
      recipient,
      relayerFee,
      relayer,
      deadline,
      PRIVACY_TRANSFER,
      56, // 测试网改 97
    ]
  )
);

const signature = await ownerSigner.signMessage(ethers.getBytes(inner));
const { v, r, s } = ethers.Signature.from(signature);

await contract.connect(relayerSigner).withdrawWithSig(
  secret,
  recipient,     // owner，必须与承诺绑定地址一致
  recipient,     // 资金打入地址
  relayerFee,
  relayer,
  deadline,
  v,
  r,
  s
);
```

`relayerFee > 0` 时，费用从票据余额中扣，付给 `relayer`，代币种类与票据相同（BNB 票据付 BNB，USDT 票据付 USDT）。

---

## 4. 隐私协议合约用法

部署后常用方法：

```js
const policy = new ethers.Contract(PRIVACY_POLICY, policyAbi, signer);

// 读当前版本与文档地址
const [
  version, contentHash, uri, effectiveAt,
  project, operator, email, site,
] = await policy.currentPolicy();

// 读某一章摘要（1 ~ 14）
const [title, body] = await policy.getSection(1);

// 校验本地全文是否与链上哈希一致
const ok = await policy.verifyContent(ethers.toUtf8Bytes(全文));

// 用户确认当前版本（每个地址每个版本一次）
await policy.accept();
const accepted = await policy.hasAccepted(userAddress);
```

运营方更新协议：

```js
await policy.updatePolicy(
  version + 1n,
  newContentHash,
  "ipfs://新CID"
);
```

用户在新版本上需要重新 `accept()`。

---

## 5. PrivacyTransfer 接口一览

### 写入

| 方法 | 说明 |
|------|------|
| `deposit(bytes32 commitment) payable` | 存入 BNB |
| `depositToken(address token, uint256 amount, bytes32 commitment)` | 存入 BEP20，需先 `approve` |
| `stealthTransfer(bytes32 secret, bytes32 toCommitment, uint256 amount, bytes32 changeCommitment)` | 合约内划转 |
| `withdraw(bytes32 secret, address recipient)` | 绑定钱包自行提现 |
| `withdrawWithSig(...)` | 签名代付提现 |

### 只读

| 方法 | 说明 |
|------|------|
| `computeCommitment(bytes32 secret, address owner)` | 计算承诺 |
| `noteOf(bytes32 commitment)` | 返回 `(token, amount)`，`token = 0x0` 为 BNB |
| `spent(bytes32 commitment)` | 该承诺是否已花费（不可复用） |

### 事件

- `Deposited(commitment, token, amount)` — 无收款地址
- `StealthTransferred(fromCommitment, toCommitment, changeCommitment, token, amount)` — 无钱包地址
- `Withdrawn(commitment, token, amount)` — 事件无地址；BNB 内部交易 / BEP20 `Transfer` 仍会显示收款地址

不要向合约直接转 BNB（`receive` 会拒绝），必须走 `deposit`。

---

## 6. 常见错误

| 错误 | 原因与处理 |
|------|------------|
| `UnsupportedChain` | 当前网络不是 BSC 56/97 |
| `ZeroAmount` | 存款或到账金额为 0 |
| `InvalidSecret` | `secret` 或 `owner` 为空，或签名者不匹配 |
| `InvalidCommitment` | 承诺为 0 |
| `CommitmentTaken` | 该承诺已有余额或已花费，必须换新的 secret |
| `NoteNotFound` | 承诺下没有资金，或 secret/钱包不匹配 |
| `InsufficientNote` | 划转金额大于票据余额 |
| `ChangeRequired` | 部分划转时未提供找零承诺 |
| `ChangeNotAllowed` | 全额划转时找零承诺必须为 `0x00…00` |
| `DuplicateCommitment` | 新旧承诺重复 |
| `FeeTooHigh` | 代付费大于票据余额 |
| `SignatureExpired` | `deadline` 已过 |
| `TokenTransferFailed` | 未 approve、余额不足或代币拒绝转账 |

---

## 7. 安全注意

1. **`secret` 等同私钥。** 谁持有 `secret` 且能用绑定钱包（或对应签名），谁就能划走资金。用 `ethers.randomBytes(32)` 生成，离线备份。
2. **承诺必须绑定将要调用 `withdraw` / `stealthTransfer` 的那个地址。** 绑错地址，资金无法提取。
3. **每个 `commitment` 只能用一次。** 花费后 `spent` 为 true，不能再存入同一承诺。
4. **扣费代币**（部分 BSC 代币转账会扣税）：合约按实际到账金额记账，不是按你传入的 `amount`。
5. **先 approve 再 `depositToken`。** `approve` 本身会在代币合约上暴露你的地址，这是 BEP20 机制决定的。
6. **不要把 `secret` 发到公开频道、不要写进合约、不要当 commitment 发给对方。** 只传 `commitment`。
7. 合约无 owner，无法暂停、无法代提、无法升级。

---

## 8. 最小 ABI（隐匿转账）

```json
[
  "function computeCommitment(bytes32 secret, address owner) view returns (bytes32)",
  "function noteOf(bytes32 commitment) view returns (address token, uint256 amount)",
  "function spent(bytes32 commitment) view returns (bool)",
  "function deposit(bytes32 commitment) payable",
  "function depositToken(address token, uint256 amount, bytes32 commitment)",
  "function stealthTransfer(bytes32 secret, bytes32 toCommitment, uint256 amount, bytes32 changeCommitment)",
  "function withdraw(bytes32 secret, address recipient)",
  "function withdrawWithSig(bytes32 secret, address owner, address recipient, uint256 relayerFee, address relayer, uint256 deadline, uint8 v, bytes32 r, bytes32 s)",
  "event Deposited(bytes32 indexed commitment, address indexed token, uint256 amount)",
  "event StealthTransferred(bytes32 indexed fromCommitment, bytes32 indexed toCommitment, bytes32 changeCommitment, address token, uint256 amount)",
  "event Withdrawn(bytes32 indexed commitment, address indexed token, uint256 amount)"
]
```
